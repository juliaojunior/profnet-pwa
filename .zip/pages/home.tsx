// pages/home.tsx
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { Layout } from '../components/Layout';

export default function HomePage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    onAuthStateChanged(auth, (user) => {
      if (!user) {
        router.replace('/login');
      } else {
        setLoading(false);
      }
    });
  }, [router]);

  if (loading) return null;

  return (
    <Layout>
      <h1 style={{ textAlign: 'center', color: '#2D3748', marginBottom: 24 }}>Bem-vindo</h1>

      <div style={{ maxWidth: 800, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 24 }}>
        <Card title="Perfil" href="/profile" color="#6B46C1" />
        <Card title="Notícias" href="/noticias" color="#2B6CB0" />
        <Card title="Mensagens" href="/mensagens" color="#2F855A" />
        <Card title="Gerador" href="/gerador" color="#DD6B20" />
      </div>
    </Layout>
  );
}

function Card({ title, href, color }: { title: string; href: string; color: string }) {
  const router = useRouter();
  return (
    <div
      onClick={() => router.push(href)}
      style={{
        background: color,
        color: 'white',
        padding: 24,
        borderRadius: 16,
        boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
        cursor: 'pointer',
        textAlign: 'center',
        transition: 'transform 0.2s',
      }}
      onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.03)')}
      onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
    >
      <h2 style={{ margin: 0 }}>{title}</h2>
    </div>
  );
}
