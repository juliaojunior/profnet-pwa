// pages/mensagens.tsx
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { onAuthStateChanged } from 'firebase/auth';
import {
  addDoc,
  collection,
  getDocs,
  query,
  orderBy,
  deleteDoc,
  doc,
  updateDoc,
  increment,
  arrayUnion,
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { Layout } from '../components/Layout';

interface Mensagem {
  id: string;
  texto: string;
  uid: string;
  autor: string;
  photoURL?: string | null;
  data: string;
  likes: number;
  likedBy?: string[];
}

function formatarTempo(data: string): string {
  const segundos = Math.floor((Date.now() - new Date(data).getTime()) / 1000);
  const minutos = Math.floor(segundos / 60);
  const horas = Math.floor(minutos / 60);
  const dias = Math.floor(horas / 24);
  if (segundos < 60) return `há ${segundos} segundos`;
  if (minutos < 60) return `há ${minutos} minutos`;
  if (horas < 24) return `há ${horas} horas`;
  return `há ${dias} dias`;
}

export default function MensagensPage() {
  const router = useRouter();
  const adminEmails = ['admin@email.com', 'juliaojunior@gmail.com'];
  const [user, setUser] = useState<any>(null);
  const [texto, setTexto] = useState('');
  const [mensagens, setMensagens] = useState<Mensagem[]>([]);
  const [filtro, setFiltro] = useState<'todas' | 'minhas'>('todas');
  const [respostas, setRespostas] = useState<{ [key: string]: string }>({});
  const [respostasSalvas, setRespostasSalvas] = useState<{ [key: string]: any[] }>({});

  // Carrega usuário, mensagens e respostas
  useEffect(() => {
    onAuthStateChanged(auth, async (u) => {
      if (!u) {
        router.replace('/login');
        return;
      }
      setUser(u);
      // Mensagens
      const q = query(collection(db, 'mensagens'), orderBy('data', 'desc'));
      const snap = await getDocs(q);
      const lista = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) } as Mensagem));
      setMensagens(lista);
      // Respostas
      const respSnap = await getDocs(collection(db, 'respostas'));
      const agrupadas: { [key: string]: any[] } = {};
      respSnap.docs.forEach((d) => {
        const r = d.data();
        if (!agrupadas[r.mensagemId]) agrupadas[r.mensagemId] = [];
        agrupadas[r.mensagemId].push({ id: d.id, ...r });
      });
      setRespostasSalvas(agrupadas);
    });
  }, [router]);

  // Enviar nova mensagem
  const palavrasProibidas = ['palavrão1', 'palavrão2', 'ofensa'];

  const enviarMensagem = async () => {
    if (!texto.trim()) return;
    const textoLimpo = texto.toLowerCase();
    if (palavrasProibidas.some(p => textoLimpo.includes(p))) {
      alert('Sua mensagem contém palavras inadequadas.');
      return;
    }
    if (texto.length > 200) {
      alert('Máximo de 200 caracteres.');
      return;
    }
    const newDoc = await addDoc(collection(db, 'mensagens'), {
      texto,
      uid: user.uid,
      autor: user.email,
      photoURL: user.photoURL || null,
      data: new Date().toISOString(),
      likes: 0,
      likedBy: [],
    });
    setTexto('');
    setMensagens((prev) => [
      {
        id: newDoc.id,
        texto,
        uid: user.uid,
        autor: user.email || '',
        photoURL: user.photoURL || null,
        data: new Date().toISOString(),
        likes: 0,
        likedBy: [],
      },
      ...prev,
    ]);
  };

  // Curtir mensagem
  const curtirMensagem = async (msg: Mensagem) => {
    if (!user || msg.uid === user.uid || msg.likedBy?.includes(user.uid)) return;
    const refMsg = doc(db, 'mensagens', msg.id);
    await updateDoc(refMsg, {
      likes: increment(1),
      likedBy: arrayUnion(user.uid),
    });
    setMensagens((prev) =>
      prev.map((m) =>
        m.id === msg.id
          ? { ...m, likes: m.likes + 1, likedBy: [...(m.likedBy || []), user.uid] }
          : m
      )
    );
  };

  // Excluir mensagem
  const excluirMensagem = async (msg: Mensagem) => {
    if (confirm('Deseja excluir esta mensagem?')) {
      await deleteDoc(doc(db, 'mensagens', msg.id));
      setMensagens((prev) => prev.filter((m) => m.id !== msg.id));
      setRespostas((prev) => {
        const novo = { ...prev };
        delete novo[msg.id];
        return novo;
      });
    }
  };

  // Enviar resposta
  const enviarResposta = async (msgId: string) => {
    const textoResp = respostas[msgId];
    const textoLimpo = textoResp?.toLowerCase();
    if (palavrasProibidas.some(p => textoLimpo.includes(p))) {
      alert('Sua resposta contém palavras inadequadas.');
      return;
    }
    if (!textoResp?.trim()) return;
    const docRef = await addDoc(collection(db, 'respostas'), {
      mensagemId: msgId,
      texto: textoResp,
      autor: user.email,
      uid: user.uid,
      data: new Date().toISOString(),
    });
    setRespostas((prev) => ({ ...prev, [msgId]: '' }));
    setRespostasSalvas((prev) => ({
      ...prev,
      [msgId]: [
        ...(prev[msgId] || []),
        { id: docRef.id, mensagemId: msgId, texto: textoResp, autor: user.email || '', uid: user.uid, data: new Date().toISOString() },
      ],
    }));
  };

  return (
    <Layout>
      
      <h1 style={{ textAlign: 'center', color: '#2D3748' }}>Mensagens</h1>

      <div style={{ textAlign: 'center', marginTop: 8 }}>
        <button
          onClick={() => setFiltro('todas')}
          style={{ marginRight: 8, background: filtro === 'todas' ? '#4C51BF' : '#E2E8F0', color: filtro === 'todas' ? 'white' : '#2D3748', border: 'none', borderRadius: 6, padding: '6px 12px', cursor: 'pointer' }}
        >
          Todas
        </button>
        <button
          onClick={() => setFiltro('minhas')}
          style={{ background: filtro === 'minhas' ? '#4C51BF' : '#E2E8F0', color: filtro === 'minhas' ? 'white' : '#2D3748', border: 'none', borderRadius: 6, padding: '6px 12px', cursor: 'pointer' }}
        >
          Minhas Mensagens
        </button>
      </div>

      <div style={{ position: 'fixed', bottom: 16, left: 0, right: 0, margin: '0 auto', maxWidth: 600, background: '#fff', borderTop: '1px solid #CBD5E0', padding: 16, display: 'flex', flexDirection: 'column', gap: 8, boxShadow: '0 -2px 6px rgba(0,0,0,0.05)', zIndex: 10 }}>
  <textarea
    placeholder="Escreva sua mensagem (máx. 200 caracteres)"
    value={texto}
    onChange={(e) => setTexto(e.target.value)}
    maxLength={200}
    style={{ padding: 12, borderRadius: 12, border: '1px solid #CBD5E0', minHeight: 60, background: '#F7FAFC', resize: 'none' }}
  />
  <button
    onClick={enviarMensagem}
    style={{ padding: '8px 16px', background: '#6B46C1', color: 'white', borderRadius: 8, border: 'none', alignSelf: 'flex-end' }}
  >
    Publicar
  </button>
</div>

      <div style={{ maxWidth: 600, margin: '0 auto', marginTop: 32, display: 'flex', flexDirection: 'column', gap: 16 }}>
        {mensagens.filter(msg => filtro === 'todas' || msg.uid === user?.uid).map((msg) => (
          <div
            key={msg.id}
            style={{ background: '#E9F5FF', padding: 16, borderRadius: 16, boxShadow: '0 2px 6px rgba(0,0,0,0.06)', display: 'flex', gap: 12, height: '300px', overflowY: 'auto' }}
          >
            <img
              src={msg.photoURL || '/icons/icon-192x192.png'}
              width={40}
              height={40}
              alt="avatar"
              style={{ borderRadius: '50%', objectFit: 'cover' }}
            />
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: '#718096' }}>
                <span>{msg.autor}</span>
                <span>{formatarTempo(msg.data)}</span>
              </div>

              <p style={{ marginBottom: 8, marginTop: 4, whiteSpace: 'pre-line' }}>{msg.texto}</p>

              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                {(msg.uid === user.uid || adminEmails.includes(user.email)) && (
                  <button
                    onClick={() => excluirMensagem(msg)}
                    style={{ padding: '4px 8px', background: '#E53E3E', color: 'white', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12 }}
                  >
                    Excluir
                  </button>
                )}
                <button
                  onClick={() => curtirMensagem(msg)}
                  disabled={msg.uid === user.uid || msg.likedBy?.includes(user.uid)}
                  style={{
                    padding: '4px 8px',
                    background: msg.likedBy?.includes(user.uid) ? '#E2E8F0' : '#EDF2F7',
                    border: '1px solid #CBD5E0',
                    borderRadius: 6,
                    cursor: msg.uid === user.uid || msg.likedBy?.includes(user.uid) ? 'not-allowed' : 'pointer',
                    fontSize: 12,
                  }}
                >
                  👍 Curtir
                </button>
                <span style={{ fontSize: 12 }}>{msg.likes} curtidas</span>
              </div>

              {respostasSalvas[msg.id]?.map((r) => (
                <div key={r.id} style={{ marginTop: 8, background: '#F0F4F8', padding: 10, borderRadius: 12, fontSize: 13, marginLeft: 48, borderLeft: '3px solid #90CDF4', maxHeight: '120px', overflowY: 'auto' }}>
                  <strong style={{ color: '#4A5568' }}>{r.autor}</strong>: {r.texto}
                </div>
              ))}

              <div style={{ marginTop: 12 }}>
                <textarea
                  value={respostas[msg.id] || ''}
                  onChange={(e) => setRespostas({ ...respostas, [msg.id]: e.target.value })}
                  placeholder="Responder..."
                  maxLength={200}
                  style={{ width: '100%', minHeight: 60, padding: 8, borderRadius: 6, border: '1px solid #CBD5E0' }}
                />
                <button
                  onClick={() => enviarResposta(msg.id)}
                  style={{ marginTop: 4, background: '#2B6CB0', color: 'white', border: 'none', padding: '6px 12px', borderRadius: 6, cursor: 'pointer', fontSize: 12 }}
                >
                  Enviar resposta
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 32, textAlign: 'right' }}>
        <button
          onClick={() => router.push('/home')}
          style={{ padding: '8px 16px', background: '#EDF2F7', color: '#4A5568', border: '1px solid #CBD5E0', borderRadius: 8, cursor: 'pointer' }}
        >
          Voltar à Home
        </button>
      </div>
          <div style={{ position: 'fixed', bottom: 16, left: 16, zIndex: 1000, display: 'flex', gap: 12 }}>
        <button onClick={() => router.push('/profile')} style={{ padding: '10px', background: '#4C51BF', color: 'white', borderRadius: '50%', border: 'none', cursor: 'pointer' }}>
          👤
        </button>
        <button onClick={() => router.push('/noticias')} style={{ padding: '10px', background: '#2B6CB0', color: 'white', borderRadius: '50%', border: 'none', cursor: 'pointer' }}>
          📰
        </button>
        <button onClick={() => router.push('/mensagens')} style={{ padding: '10px', background: '#2F855A', color: 'white', borderRadius: '50%', border: 'none', cursor: 'pointer' }}>
          💬
        </button>
        <button onClick={() => router.push('/home')} style={{ padding: '10px', background: '#CBD5E0', color: '#2D3748', borderRadius: '50%', border: 'none', cursor: 'pointer' }}>
          🏠
        </button>
      </div>
    </Layout>
  );
}
