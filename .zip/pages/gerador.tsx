// pages/gerador.tsx
import { useState } from 'react';
import { useRouter } from 'next/router';
import { Layout } from '../components/Layout';

const tipos = ['Plano de Aula', 'Plano de Curso', 'Lista de Exercícios', 'Projeto Pedagógico'];

export default function GeradorPage() {
  const router = useRouter();
  const [tipo, setTipo] = useState(tipos[0]);
  const [titulo, setTitulo] = useState('');
  const [objetivo, setObjetivo] = useState('');
  const [publico, setPublico] = useState('');
  const [disciplina, setDisciplina] = useState('');
  const [conteudos, setConteudos] = useState('');
  const [recursos, setRecursos] = useState('');
  const [estrategias, setEstrategias] = useState('');
  const [avaliacao, setAvaliacao] = useState('');
  const [observacoes, setObservacoes] = useState('');
  const [resultado, setResultado] = useState('');

  const gerar = async () => {
    const prompt = `Tipo: ${tipo}\nTítulo: ${titulo}\nObjetivo: ${objetivo}\nPúblico: ${publico}\nDisciplina: ${disciplina}\nConteúdos: ${conteudos}\nRecursos: ${recursos}\nEstratégias: ${estrategias}\nAvaliação: ${avaliacao}\nObservações: ${observacoes}`;
    console.log('ENVIAR PARA API:\n', prompt);
    setResultado('📄 Aqui aparecerá o conteúdo gerado pela IA...');
  };

  return (
    <Layout>
      <h1 style={{ textAlign: 'center', color: '#4C51BF', fontSize: 28, fontWeight: 600, marginBottom: 24 }}>
        🧠 Gerador de Conteúdo com IA
      </h1>

      <div style={{ maxWidth: 800, margin: '24px auto', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <label>Tipo de Conteúdo</label>
        <select value={tipo} onChange={(e) => setTipo(e.target.value)} style={{ padding: 10, borderRadius: 8, border: '1px solid #CBD5E0', background: '#F7FAFC' }}>
          {tipos.map((t) => <option key={t}>{t}</option>)}
        </select>

        <input placeholder="Título ou Tema" value={titulo} onChange={(e) => setTitulo(e.target.value)} style={estiloInput} />
        <textarea placeholder="Objetivo Geral" value={objetivo} onChange={(e) => setObjetivo(e.target.value)} style={estiloTextArea} />
        <input placeholder="Público-Alvo" value={publico} onChange={(e) => setPublico(e.target.value)} style={estiloInput} />
        <input placeholder="Disciplina" value={disciplina} onChange={(e) => setDisciplina(e.target.value)} style={estiloInput} />
        <textarea placeholder="Conteúdos a abordar" value={conteudos} onChange={(e) => setConteudos(e.target.value)} style={estiloTextArea} />
        <textarea placeholder="Recursos didáticos" value={recursos} onChange={(e) => setRecursos(e.target.value)} style={estiloTextArea} />
        <textarea placeholder="Estratégias de ensino" value={estrategias} onChange={(e) => setEstrategias(e.target.value)} style={estiloTextArea} />
        <textarea placeholder="Avaliação" value={avaliacao} onChange={(e) => setAvaliacao(e.target.value)} style={estiloTextArea} />
        <textarea placeholder="Observações adicionais" value={observacoes} onChange={(e) => setObservacoes(e.target.value)} style={estiloTextArea} />

        <button onClick={gerar} style={{ marginTop: 12, background: '#4C51BF', color: 'white', padding: '12px 16px', border: 'none', borderRadius: 8, fontSize: 16 }}>
          🤖 Gerar Conteúdo
        </button>

        {resultado && (
          <div style={{ marginTop: 24, padding: 16, background: '#F7FAFC', border: '1px solid #CBD5E0', borderRadius: 8 }}>
            <h2 style={{ color: '#2B6CB0' }}>Resultado:</h2>
            <pre style={{ whiteSpace: 'pre-wrap' }}>{resultado}</pre>
          </div>
        )}
      </div>

      <div style={{ position: 'fixed', bottom: 16, left: 16, zIndex: 1000, display: 'flex', gap: 12 }}>
        <button onClick={() => router.push('/profile')} style={botaoFlutuante}>👤</button>
        <button onClick={() => router.push('/noticias')} style={botaoFlutuante}>📰</button>
        <button onClick={() => router.push('/mensagens')} style={botaoFlutuante}>💬</button>
        <button onClick={() => router.push('/home')} style={botaoFlutuante}>🏠</button>
      </div>
    </Layout>
  );
}

const estiloInput = {
  padding: 10,
  borderRadius: 8,
  border: '1px solid #CBD5E0',
  background: '#F7FAFC'
};

const estiloTextArea = {
  ...estiloInput,
  minHeight: 80,
  resize: 'vertical' as const
};

const botaoFlutuante = {
  padding: '10px',
  background: '#CBD5E0',
  color: '#2D3748',
  borderRadius: '50%',
  border: 'none',
  cursor: 'pointer'
};
