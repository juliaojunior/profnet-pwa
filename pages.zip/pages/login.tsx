import { useState } from 'react';
import { useRouter } from 'next/router';
import { signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup, FacebookAuthProvider } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { Layout } from '../components/Layout';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { FcGoogle } from 'react-icons/fc';
import { FaFacebookF } from 'react-icons/fa';
import Link from 'next/link';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const handleEmailLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.push('/home');
    } catch (err) {
      console.error(err);
    }
  };
  const handleGoogleLogin = async () => {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
    router.push('/profile');
  };
  const handleFacebookLogin = async () => {
    const provider = new FacebookAuthProvider();
    await signInWithPopup(auth, provider);
    router.push('/home');
  };
  return (
    <Layout>
      <div style={{ textAlign: 'center', marginBottom: 24 }}>
        <img src="/icons/icon-192x192.png" width={64} height={64} alt="Logo" />
        <h1>Bem-vindo(a) de volta</h1>
      </div>
      <Input type="email" placeholder="E-mail ou usuário" value={email} onChange={e => setEmail(e.target.value)} />
      <Input type="password" placeholder="Senha" value={password} onChange={e => setPassword(e.target.value)} />
      <div style={{ textAlign: 'right', marginBottom: 16 }}>
        <Link href="#">Esqueci minha senha</Link>
      </div>
      <Button onClick={handleEmailLogin}>Entrar</Button>
      <div style={{ textAlign: 'center', margin: '16px 0' }}>Ou continue com</div>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 16, marginBottom: 24 }}>
        <Button style={{ maxWidth: 48, padding: 8 }} onClick={handleGoogleLogin}><FcGoogle size={24} /></Button>
        <Button style={{ maxWidth: 48, padding: 8 }} onClick={handleFacebookLogin}><FaFacebookF size={24} /></Button>
      </div>
      <div style={{ textAlign: 'center' }}>
        Não tem conta? <Link href="/signup">Cadastre-se</Link>
      </div>
    </Layout>
  );
}
