// pages/noticias.tsx
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Layout } from '../components/Layout';
import { useRouter } from 'next/router';

interface Noticia {
  id: string;
  titulo: string;
  corpo: string;
  data: string;
}

export default function NoticiasPage() {
  const [noticias, setNoticias] = useState<Noticia[]>([]);
  const router = useRouter();

  useEffect(() => {
    const fetchNoticias = async () => {
      const snap = await getDocs(collection(db, 'noticias'));
      const data = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Noticia));
      const ordenadas = data.sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime());
      setNoticias(ordenadas);
    };
    fetchNoticias();
  }, []);

  return (
    <Layout>
      <h1 style={{ textAlign: 'center', color: '#2D3748' }}>Notícias</h1>
      <div style={{ maxWidth: 800, margin: '32px auto', display: 'flex', flexDirection: 'column', gap: 24 }}>
        {noticias.map((noticia) => (
          <div key={noticia.id} style={{ background: '#F9FAFB', padding: 24, borderRadius: 16, boxShadow: '0 4px 12px rgba(0,0,0,0.08)', height: '300px', overflowY: 'auto', borderLeft: '6px solid #4C51BF' }}>
            <h2 style={{ marginBottom: 8, color: '#2B6CB0', fontWeight: 'bold' }}>{noticia.titulo}</h2>
            <p style={{ color: '#2D3748', whiteSpace: 'pre-line', fontSize: 15, lineHeight: '1.6' }}>{noticia.corpo}</p>
            <small style={{ display: 'block', marginTop: 12, color: '#718096' }}>{new Date(noticia.data).toLocaleDateString()}</small>
          </div>
        ))}
      </div>

      <div style={{ position: 'fixed', bottom: 16, left: 16, zIndex: 1000, display: 'flex', gap: 12 }}>
        <button onClick={() => router.push('/profile')} style={{ padding: '10px', background: '#4C51BF', color: 'white', borderRadius: '50%', border: 'none', cursor: 'pointer' }}>
          👤
        </button>
        <button onClick={() => router.push('/noticias')} style={{ padding: '10px', background: '#2B6CB0', color: 'white', borderRadius: '50%', border: 'none', cursor: 'pointer' }}>
          📰
        </button>
        <button onClick={() => router.push('/mensagens')} style={{ padding: '10px', background: '#2F855A', color: 'white', borderRadius: '50%', border: 'none', cursor: 'pointer' }}>
          💬
        </button>
        <button onClick={() => router.push('/home')} style={{ padding: '10px', background: '#CBD5E0', color: '#2D3748', borderRadius: '50%', border: 'none', cursor: 'pointer' }}>
          🏠
        </button>
      </div>
    </Layout>
  );
}
